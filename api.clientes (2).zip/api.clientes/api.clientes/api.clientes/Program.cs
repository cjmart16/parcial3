using Microsoft.EntityFrameworkCore;
using Repository.Data;
using Services.Logica;
using FluentValidation;
using api.clientes.Validators;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllers();
builder.Services.AddEndpointsApiExplorer();
builder.Services.AddSwaggerGen();
builder.Services.AddDbContext<ApplicationDbContext>(options =>
    options.UseNpgsql(builder.Configuration.GetConnectionString("postgres"),
    b => b.MigrationsAssembly("Repository")));

// Inyecci�n de dependencias
builder.Services.AddTransient<IFactura, FacturaRepository>();
builder.Services.AddTransient<FacturaService>();
builder.Services.AddTransient<IValidator<FacturaModel>, FacturaValidator>();

builder.Services.AddTransient<ICliente, ClienteRepository>();
builder.Services.AddTransient<ClienteService>();
builder.Services.AddTransient<IValidator<ClienteModel>, ClienteValidator>();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (app.Environment.IsDevelopment())
{
    app.UseSwagger();
    app.UseSwaggerUI();
}

app.UseHttpsRedirection();
app.UseAuthorization();
app.MapControllers();
app.Run();